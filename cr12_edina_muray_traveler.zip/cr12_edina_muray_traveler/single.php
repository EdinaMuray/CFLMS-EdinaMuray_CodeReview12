<?php get_header(); ?>

<div class="container wrapper">
      <br>
      <h1>Let´s see your destination closer</h1>
      <hr>

    <div class="row">

      <?php if(have_posts()) : ?>
        <?php while (have_posts()) :the_post(); ?>

        <div class="card mb-4 text-white" style="background-color: #20c997;">
            <img src="pics/image1.jpg" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title"><?php the_title(); ?></h5>
                <p><?php the_time('F j, Y g:i a'); ?></p>   
                <p><?php the_author(); ?></p>
                <p class="card-text"><?php the_content(); ?></p>
                <a href="#" class="btn" style="background-color: #fd7e14;">Go somewhere</a>
            </div>
             <p><?php comments_template(); ?></p>
        </div>
 
       

     <?php endwhile; ?> <!-- end the while loop -->
        <?php else :?> <!-- if no posts are found then: -->
            <?php__('No Posts found'); ?> <!-- no posts found displayed -->
     <?php endif; ?>  <!-- end if -->
  
</div>
<div>

    <?php 
        if(is_active_sidebar('sidebar')):
            dynamic_sidebar('Sidebar');
        endif;
    ?>

</div>

<?php get_footer(); ?>