<?php get_header(); ?>

<div class="container-fluid wrapper">
      <br>
      <h1>Welcome on your travel!</h1>
      <br>
      <hr>

      <div class="row">

        <div class="col-sm-6 col-md-4 col-lg-3">
          <div class="card  mb-4 text-white " style="background-color: #20c997;">
            <img src="pics/image1.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Destination  1</h5>
              <p class="card-text">
                Some quick example text to build on the card title and make up the bulk of
                the card's content.
              </p>
              <a href="#" class="btn" style="background-color: #fd7e14;">
                Go somewhere
              </a>
            </div>
          </div>
        </div>

        <div class="col-sm-6 col-md-4 col-lg-3">
          <div class="card  mb-4 text-white " style="background-color: #20c997;">
            <img src="pics/image2.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Destination  1</h5>
              <p class="card-text">
                Some quick example text to build on the card title and make up the bulk of
                the card's content.
              </p>
              <a href="#" class="btn" style="background-color: #fd7e14;">
                Go somewhere
              </a>
            </div>
          </div>
        </div>

        <div class="col-sm-6 col-md-4 col-lg-3">
          <div class="card  mb-4 text-white " style="background-color: #20c997;">
            <img src="pics/image3.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Destination  1</h5>
              <p class="card-text">
                Some quick example text to build on the card title and make up the bulk of
                the card's content.
              </p>
              <a href="#" class="btn" style="background-color: #fd7e14;">
                Go somewhere
              </a>
            </div>
          </div>
        </div>

        <div class="col-sm-6 col-md-4 col-lg-3">
          <div class="card  mb-4 text-white " style="background-color: #20c997;">
            <img src="pics/image4.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Destination  1</h5>
              <p class="card-text">
                Some quick example text to build on the card title and make up the bulk of
                the card's content.
              </p>
              <a href="#" class="btn" style="background-color: #fd7e14;">
                Go somewhere
              </a>
            </div>
          </div>
        </div>

      </div>
    </div>

    

</div>

<?php get_footer(); ?>