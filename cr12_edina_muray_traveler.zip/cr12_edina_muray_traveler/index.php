<?php get_header(); ?> 

<div class="container wrapper">
    <br>
    <h1>Let´s see your destinations closer<br>
        If you want read more, click on the link below!  
    </h1>
    <hr>

    <div class="row">

        <?php if(have_posts()) : ?><!--  If there are posts available  -->
            <?php while (have_posts()) :the_post(); ?> <!-- if there are posts, iterate the posts in the loop -->

            <div class="card mb-4 text-white" style="background-color: #20c997;">
                <img src="<?php if(has_post_thumbnail()): ?> 
                            <?php the_post_thumbnail('large'); ?>
                            <?php endif; ?>" 
                    class="card-img-top" 
                    alt="..."
                >
                    <div class="card-body">
                        <h5 class="card-title">
                            <a style="color: #fd7e14;" 
                            href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h5>
                        <p><?php the_time('F j, Y g:i a'); ?></p>   
                        <p><?php the_author(); ?></p>
                        <p class="card-text"><p><?php the_excerpt(); ?></p>
                    </div>
            </div>

            <!-- <?php if(has_post_thumbnail()): ?> 
                <?php the_post_thumbnail('large'); ?>
           <?php endif; ?> --> 
            

            <?php endwhile; ?> <!-- end the while loop -->
        <?php else :?> <!-- if no posts are found then: -->
            <?php__('No Posts found'); ?> <!-- no posts found displayed -->
        <?php endif; ?>  <!-- end if -->
        
    </div>
</div>

<?php get_footer(); ?>


    