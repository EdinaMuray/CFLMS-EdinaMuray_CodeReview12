<?php get_header(); ?>

<div class="container page">
    

     <!-- All dynamic content will come in here -->
    <div class="content">

        <?php if(have_posts()) : ?><!--  If there are posts available  -->
            <?php while (have_posts()) :the_post(); ?> <!-- if there are posts, iterate the posts in the loop -->

                <h2><?php the_title(); ?></h2>  <!-- retrieves blog title -->
               
                <p><?php the_content(); ?></p> <!-- retrieves author of blog entry -->
 
            <?php endwhile; ?> <!-- end the while loop -->
        <?php else :?> <!-- if no posts are found then: -->
            <?php__('No Posts found'); ?> <!-- no posts found displayed -->
        <?php endif; ?>  <!-- end if -->
        
    </div>
</div>

<?php get_footer(); ?>